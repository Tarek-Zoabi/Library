import java.util.Scanner;
import java.util.Vector;

public class Library {
    Vector<Book> books;
    Vector<Integer> prices;


    public Library() {
        books=new Vector<>();
        prices=new Vector<>();
    }

    public Library(Vector<Book> books, Vector<Integer> prices) {
        this.books = books;
        this.prices = prices;
    }

    @Override
    public String toString() {
        return "Library{" +
                "books=" + books +
                ", prices=" + prices +
                '}';
    }

    public void addBook(Book b, int price) {
        books.add(b);
        prices.add(price);
    }

    public int amount() {
        return books.size();
    }

    public int indexOf(int bookCode) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getBookCode()==bookCode);
            return i;
        }


        return 0;
    }

    public boolean isempty() {
        if (books.size()==0)
            return true;
        else return false;
    }


    public void remove(Book b) {
        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).isEqual(b)) {
                books.remove(books.get(i));
                prices.remove(books.get(i));
                prices.remove(prices.get(i));
            }

            }

        }
    public void updatePrice(int bookCode,int price){
        for (int i=0;i<books.size();i++){
            if (books.get(i).getBookCode()==bookCode){
                prices.setElementAt(8000,i);
            }
        }

    }
    }